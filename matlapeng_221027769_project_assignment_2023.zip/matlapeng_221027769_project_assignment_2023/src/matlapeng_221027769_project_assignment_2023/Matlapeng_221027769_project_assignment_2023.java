
package matlapeng_221027769_project_assignment_2023;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.FileWriter;
import java.io.IOException;
import javafx.scene.control.TextArea;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.scene.control.Alert;

public class Matlapeng_221027769_project_assignment_2023 extends Application {
    
    private ChoiceBox<String> companyTypeChoiceBox;
    private TextField companyName;
    private TextField companyDate;
    private TextField companyEmployees;
    private CheckBox charitableCheckBox;
    private TextArea displayArea;
    
    @Override
    public void start(Stage primaryStage) {
        
        Label companyTypeLabel = new Label("Company Type:");
        companyTypeChoiceBox = new ChoiceBox<>();
        companyTypeChoiceBox.getItems().addAll("For-Profit", "Non-Profit");
        
        Label companyData = new Label("Company Data");
        Label nameLabel = new Label("Company Name:");
        companyName = new TextField();
        companyName.setPromptText("e.g., Example Company");
        companyName.setDisable(true);

        Label dateLabel = new Label("Company Date:");
        companyDate = new TextField();
        companyDate.setPromptText("yyyy-MM-dd");
        companyDate.setDisable(true);

        Label employeeLabel = new Label("Number of Employees:");
        companyEmployees = new TextField();
        companyEmployees.setPromptText("e.g., 100");
        companyEmployees.setDisable(true);

        charitableCheckBox = new CheckBox("Charitable");
        charitableCheckBox.setDisable(true);

        Button addCompanyButton = new Button("Add Company");
        Button clearDataButton = new Button("Clear Fields");
        
        displayArea = new TextArea();
        displayArea.setWrapText(true);
        displayArea.setEditable(false);


        GridPane gridPane = new GridPane();
        gridPane.setVgap(10);

        // Add UI elements to the grid
        gridPane.add(companyTypeLabel, 0, 0);
        gridPane.add(companyTypeChoiceBox, 0, 1);
        gridPane.add(companyData, 1, 0);
        gridPane.add(nameLabel, 1, 1);
        gridPane.add(companyName, 2, 1);
        gridPane.add(dateLabel, 1, 2);
        gridPane.add(companyDate, 2, 2);
        gridPane.add(employeeLabel, 1, 3);
        gridPane.add(companyEmployees, 2, 3);
        gridPane.add(charitableCheckBox, 1, 4);
        
        VBox vbox = new VBox(10);
        vbox.getChildren().addAll(gridPane, addCompanyButton, clearDataButton, displayArea);
        
          companyTypeChoiceBox.setOnAction(event -> {
            String selectedType = companyTypeChoiceBox.getValue();
            if ("For-Profit".equals(selectedType)) {
                companyName.setDisable(false);
                companyDate.setDisable(false);
                companyEmployees.setDisable(false);
                charitableCheckBox.setDisable(true);
                charitableCheckBox.setSelected(false);
            } else if ("Non-Profit".equals(selectedType)) {
                companyName.setDisable(false);
                companyDate.setDisable(false);
                companyEmployees.setDisable(true);
                companyEmployees.clear();
                charitableCheckBox.setDisable(false);
            } else {
                companyName.setDisable(true);
                companyDate.setDisable(true);
                companyEmployees.setDisable(true);
                companyEmployees.clear();
                charitableCheckBox.setDisable(true);
                charitableCheckBox.setSelected(false);
            }
        });

       addCompanyButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                String type = companyTypeChoiceBox.getValue();
                if (type == null) {
                    // Company type is not specified
                    return;
                }
                String name = companyName.getText();
                String date = companyDate.getText();
                
                if (!isValidDateFormat(date)) {
                displayAlert("Invalid Date Format", "Please enter the date in the format yyyy-MM-dd.");
                return;
            }

            // Validate company name
            if (!isValidCompanyName(name)) {
                displayAlert("Invalid Company Name", "Please enter a valid company name.");
                return;
            }

            // Validate number of employees
           
                
                String dataToDisplay = "Company Name: " + name + "\n" +
                        "Company Date: " + date + "\n" +
                        "Company Type: " + type;

                if ("For-Profit".equals(type)) {
                    String employees = companyEmployees.getText();
                    dataToDisplay += "\nNumber of Employees: " + employees;
                     if (!isValidNumberOfEmployees(employees)) {
                displayAlert("Invalid Number of Employees", "Please enter a valid number of employees.");
                return;
            }
                } else if ("Non-Profit".equals(type)) {
                    boolean isCharitable = charitableCheckBox.isSelected();
                    if (isCharitable) {
                        dataToDisplay += "\nCharitable Status: Charitable";
                    } else {
                        dataToDisplay += "\nCharitable Status: Not Charitable";
                    }
                }
                dataToDisplay += "\n\n";
                displayArea.appendText(dataToDisplay);
                // Write data to a text file
                try (FileWriter fileWriter = new FileWriter("company_data.txt", true)) {
                    fileWriter.write(dataToDisplay);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
       
        clearDataButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                companyTypeChoiceBox.setValue(null);
                companyName.clear();
                companyDate.clear();
                companyEmployees.clear();
                charitableCheckBox.setSelected(false);
              //  displayArea.clear();
            }
        });

        Scene scene = new Scene(vbox, 800, 500);
        primaryStage.setTitle("Company Data");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
    
    private boolean isValidDateFormat(String date) {
        String regex = "\\d{4}-\\d{2}-\\d{2}";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(date);
        return matcher.matches();
    }

    private boolean isValidCompanyName(String name) {
        // Add your company name validation logic here
        return !name.trim().isEmpty();
    }

    private boolean isValidNumberOfEmployees(String employees) {
        String regex = "\\d+";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(employees);
        return matcher.matches();
    }

    private void displayAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
    
}
